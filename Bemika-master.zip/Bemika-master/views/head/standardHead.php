<!DOCTYPE HTML>
<html lang="">
<head>
    <meta charset="UTF-8">
    <title>Welkom bij Bemika $which_page</title>
	<link rel="stylesheet" type="text/css" href="css/parts/<?php echo $which_page; ?>.css">
	<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
    <script src="javascript/topscript.js" type="text/javascript"></script>
</head>